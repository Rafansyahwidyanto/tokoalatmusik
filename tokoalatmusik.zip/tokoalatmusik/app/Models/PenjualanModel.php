<?php

namespace App\Models;

use CodeIgniter\Model;

class PenjualanModel extends Model
{
    protected $table      = 'penjualan';
    protected $primaryKey = 'id_penjualan';

    protected $allowedFields = [
        'id_barang',
        'id_customer',
        'tanggal',
        'qty',
        'total'
    ];

    public function getPenjualan()
    {
        return $this->db->table('penjualan')
            ->select('penjualan.*, barang.nama_barang, customer.nama_customer')
            ->join('barang', 'barang.id_barang = penjualan.id_barang')
            ->join('customer', 'customer.id_customer = penjualan.id_customer')
            ->get()
            ->getResultArray();
    }
}
