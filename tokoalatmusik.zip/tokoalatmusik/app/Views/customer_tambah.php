<?= view('header') ?>

<h3>Tambah Customer</h3>

<form method="post" action="/customer/simpan">
  <div class="mb-3">
    <label>Nama Customer</label>
    <input type="text" name="nama_customer" class="form-control" required>
  </div>

  <div class="mb-3">
    <label>Alamat</label>
    <textarea name="alamat" class="form-control" required></textarea>
  </div>

  <div class="mb-3">
    <label>No HP</label>
    <input type="text" name="no_hp" class="form-control" required>
  </div>

  <button class="btn btn-success">Simpan</button>
  <a href="/customer" class="btn btn-secondary">Kembali</a>
</form>

<?= view('footer') ?>
