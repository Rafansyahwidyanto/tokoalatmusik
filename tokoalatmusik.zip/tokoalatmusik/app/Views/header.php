<!DOCTYPE html>
<html>
<head>
    <title>Toko Alat Musik</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container">
    <a class="navbar-brand" href="/">Toko Alat Musik</a>
    <ul class="navbar-nav">
      <li class="nav-item"><a href="/barang" class="nav-link">Barang</a></li>
      <li class="nav-item"><a href="/customer" class="nav-link">Customer</a></li>
      <li class="nav-item"><a href="/penjualan" class="nav-link">Penjualan</a></li>
      <li class="nav-item"><a href="/laporan" class="nav-link">Laporan</a></li>
    </ul>
  </div>
</nav>

<div class="container mt-4">
