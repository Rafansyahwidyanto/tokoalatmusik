<?= view('header') ?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h4>Data Customer</h4>

    <a href="/customer/tambah" class="btn btn-primary">
        Tambah Customer
    </a>
</div>

<div class="card">
    <div class="card-body">

        <table class="table table-bordered table-striped">
            <thead class="table-dark">
                <tr class="text-center">
                    <th width="5%">No</th>
                    <th>Nama Customer</th>
                    <th>Alamat</th>
                    <th width="15%">No HP</th>
                    <th width="20%">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($customer)) : ?>
                    <?php $no = 1; foreach ($customer as $c) : ?>
                        <tr>
                            <td class="text-center"><?= $no++ ?></td>
                            <td><?= esc($c['nama_customer']) ?></td>
                            <td><?= esc($c['alamat']) ?></td>
                            <td class="text-center"><?= esc($c['no_hp']) ?></td>
                            <td class="text-center">

                                <a href="/customer/edit/<?= $c['id_customer'] ?>" 
                                   class="btn btn-warning btn-sm">
                                    Edit
                                </a>

                                <a href="/customer/hapus/<?= $c['id_customer'] ?>"
                                   class="btn btn-danger btn-sm"
                                   onclick="return confirm('Yakin ingin menghapus data ini?')">
                                    Hapus
                                </a>

                            </td>
                        </tr>
                    <?php endforeach ?>
                <?php else : ?>
                    <tr>
                        <td colspan="5" class="text-center text-muted">
                            Data customer belum tersedia
                        </td>
                    </tr>
                <?php endif ?>
            </tbody>
        </table>

    </div>
</div>

<?= view('footer') ?>
