<?= view('header') ?>

<h4>Edit Barang</h4>

<form action="/barang/update/<?= $barang['id_barang'] ?>" method="post">
    
    <div class="mb-2">
        <label>Nama Barang</label>
        <input type="text" name="nama_barang"
               value="<?= esc($barang['nama_barang']) ?>"
               class="form-control" required>
    </div>

    <div class="mb-2">
        <label>Harga</label>
        <input type="number" name="harga"
               value="<?= esc($barang['harga']) ?>"
               class="form-control" required>
    </div>

    <div class="mb-2">
        <label>Stok</label>
        <input type="number" name="stok"
               value="<?= esc($barang['stok']) ?>"
               class="form-control" required>
    </div>

    <button class="btn btn-primary">Edit</button>
    <a href="/barang" class="btn btn-secondary">Kembali</a>
</form>

<?= view('footer') ?>
