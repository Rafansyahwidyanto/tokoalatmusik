<?= view('header') ?>

<h4 class="mb-3">Edit Customer</h4>

<div class="card">
    <div class="card-body">

        <form action="/customer/update/<?= $customer['id_customer'] ?>" method="post">

            <div class="mb-3">
                <label class="form-label">Nama Customer</label>
                <input type="text"
                       name="nama_customer"
                       class="form-control"
                       value="<?= esc($customer['nama_customer']) ?>"
                       required>
            </div>

            <div class="mb-3">
                <label class="form-label">Alamat</label>
                <textarea name="alamat"
                          class="form-control"
                          rows="3"
                          required><?= esc($customer['alamat']) ?></textarea>
            </div>

            <div class="mb-3">
                <label class="form-label">No HP</label>
                <input type="text"
                       name="no_hp"
                       class="form-control"
                       value="<?= esc($customer['no_hp']) ?>"
                       required>
            </div>

            <button type="submit" class="btn btn-success">
                Update
            </button>

            <a href="/customer" class="btn btn-secondary">
                Kembali
            </a>

        </form>

    </div>
</div>

<?= view('footer') ?>
