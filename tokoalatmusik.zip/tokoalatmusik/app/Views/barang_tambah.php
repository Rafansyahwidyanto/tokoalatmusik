<?= view('header') ?>

<h3>Tambah Barang</h3>

<form method="post" action="/barang/simpan">
  <div class="mb-3">
    <label>Nama Barang</label>
    <input type="text" name="nama_barang" class="form-control" required>
  </div>

  <div class="mb-3">
    <label>Harga</label>
    <input type="number" name="harga" class="form-control" required>
  </div>

  <div class="mb-3">
    <label>Stok</label>
    <input type="number" name="stok" class="form-control" required>
  </div>

  <button class="btn btn-success">Simpan</button>
  <a href="/barang" class="btn btn-secondary">Kembali</a>
</form>

<?= view('footer') ?>
