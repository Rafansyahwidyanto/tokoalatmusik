<?= view('header') ?>

<h4 class="mb-3">Edit Penjualan</h4>

<form action="/penjualan/update/<?= $penjualan['id_penjualan'] ?>" method="post">

    <div class="mb-2">
        <label class="form-label">Tanggal</label>
        <input type="date"
               name="tanggal"
               value="<?= $penjualan['tanggal'] ?>"
               class="form-control"
               required>
    </div>

    <div class="mb-2">
        <label class="form-label">Customer</label>
        <select name="id_customer" class="form-control" required>
            <?php foreach ($customer as $c): ?>
                <option value="<?= $c['id_customer'] ?>"
                    <?= $c['id_customer'] == $penjualan['id_customer'] ? 'selected' : '' ?>>
                    <?= esc($c['nama_customer']) ?>
                </option>
            <?php endforeach ?>
        </select>
    </div>

    <div class="mb-2">
        <label class="form-label">Barang</label>
        <select name="id_barang" id="barang" class="form-control" required>
            <?php foreach ($barang as $b): ?>
                <option value="<?= $b['id_barang'] ?>"
                        data-harga="<?= $b['harga'] ?>"
                    <?= $b['id_barang'] == $penjualan['id_barang'] ? 'selected' : '' ?>>
                    <?= esc($b['nama_barang']) ?>
                </option>
            <?php endforeach ?>
        </select>
    </div>

    <div class="mb-2">
        <label class="form-label">Qty</label>
        <input type="number"
               name="qty"
               id="qty"
               value="<?= $penjualan['qty'] ?>"
               class="form-control"
               required>
    </div>

    <div class="mb-3">
        <label class="form-label">Total (Otomatis)</label>
        <input type="text"
               id="total"
               class="form-control bg-light"
               value="Rp <?= number_format($penjualan['total'],0,',','.') ?>"
               readonly>
        </small>
    </div>

    <button class="btn btn-primary">Edit</button>
    <a href="/penjualan" class="btn btn-secondary">Kembali</a>
</form>

<script>
const barang = document.getElementById('barang');
const qty    = document.getElementById('qty');
const total  = document.getElementById('total');

function hitungTotal() {
    const harga = barang.options[barang.selectedIndex].dataset.harga || 0;
    const jumlah = qty.value || 0;
    total.value = 'Rp ' + (harga * jumlah).toLocaleString('id-ID');
}

barang.addEventListener('change', hitungTotal);
qty.addEventListener('input', hitungTotal);
</script>

<?= view('footer') ?>
