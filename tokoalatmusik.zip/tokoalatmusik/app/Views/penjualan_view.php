<?= view('header') ?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h4>Data Penjualan</h4>
    <a href="/penjualan/tambah" class="btn btn-primary">
        Tambah Penjualan
    </a>
</div>

<div class="card">
    <div class="card-body">

        <table class="table table-bordered table-striped">
            <thead class="table-dark">
                <tr class="text-center">
                    <th width="5%">No</th>
                    <th>Tanggal</th>
                    <th>Customer</th>
                    <th>Barang</th>
                    <th width="8%">Qty</th>
                    <th>Total</th>
                    <th width="15%">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($penjualan)) : ?>
                    <?php $no = 1; foreach ($penjualan as $p) : ?>
                        <tr>
                            <td class="text-center"><?= $no++ ?></td>
                            <td><?= esc($p['tanggal']) ?></td>
                            <td><?= esc($p['nama_customer']) ?></td>
                            <td><?= esc($p['nama_barang']) ?></td>
                            <td class="text-center"><?= esc($p['qty']) ?></td>
                            <td class="text-end">
                                Rp <?= number_format($p['total'], 0, ',', '.') ?>
                            </td>
                            <td class="text-center">
                                <a href="/penjualan/edit/<?= $p['id_penjualan'] ?>"
                                   class="btn btn-warning btn-sm">
                                    Edit
                                </a>

                                <a href="/penjualan/hapus/<?= $p['id_penjualan'] ?>"
                                   class="btn btn-danger btn-sm"
                                   onclick="return confirm('Yakin ingin menghapus data ini?')">
                                    Hapus
                                </a>
                            </td>
                        </tr>
                    <?php endforeach ?>
                <?php else : ?>
                    <tr>
                        <td colspan="7" class="text-center text-muted">
                            Data penjualan belum tersedia
                        </td>
                    </tr>
                <?php endif ?>
            </tbody>
        </table>

    </div>
</div>

<?= view('footer') ?>
