<?= view('header') ?>

<h3 class="mb-4">Dashboard</h3>

<div class="row">

  <div class="col-md-3">
    <div class="card text-white bg-primary mb-3">
      <div class="card-body text-center">
        <h5>Total Barang</h5>
        <h2><?= $total_barang ?></h2>
      </div>
    </div>
  </div>

  <div class="col-md-3">
    <div class="card text-white bg-success mb-3">
      <div class="card-body text-center">
        <h5>Total Customer</h5>
        <h2><?= $total_customer ?></h2>
      </div>
    </div>
  </div>

  <div class="col-md-3">
    <div class="card text-white bg-warning mb-3">
      <div class="card-body text-center">
        <h5>Total Penjualan</h5>
        <h2><?= $total_penjualan ?></h2>
      </div>
    </div>
  </div>

  <div class="col-md-3">
    <div class="card text-white bg-danger mb-3">
      <div class="card-body text-center">
        <h5>Total Pendapatan</h5>
        <h4>Rp <?= number_format($total_pendapatan) ?></h4>
      </div>
    </div>
  </div>

</div>

<div class="card mt-4">
  <div class="card-body">
    <h5>Selamat Datang 👋</h5>
    <p>
      Ini adalah aplikasi <strong>Penjualan Toko Alat Musik</strong> 
      berbasis <strong>CodeIgniter 4</strong> dan <strong>MySQL</strong>.
      Aplikasi ini memiliki fitur master data, transaksi penjualan,
      serta laporan penjualan.
    </p>
  </div>
</div>

<?= view('footer') ?>
