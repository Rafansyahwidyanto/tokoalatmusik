<?= view('header') ?>

<h3>Laporan Penjualan</h3>

<table class="table table-bordered">
<tr>
  <th>No</th>
  <th>Tanggal</th>
  <th>Customer</th>
  <th>Total</th>
</tr>

<?php $no=1; foreach($laporan as $l): ?>
<tr>
  <td><?= $no++ ?></td>
  <td><?= $l->tanggal ?></td>
  <td><?= $l->nama_customer ?></td>
  <td>Rp <?= number_format($l->total) ?></td>
</tr>
<?php endforeach ?>
</table>

<?= view('footer') ?>
