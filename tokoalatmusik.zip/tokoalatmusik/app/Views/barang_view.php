<?= view('header') ?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h4>Data Barang</h4>

    <a href="/barang/tambah" class="btn btn-primary">
        Tambah Barang
    </a>
</div>

<div class="card">
    <div class="card-body">

        <table class="table table-bordered table-striped">
            <thead class="table-dark">
                <tr class="text-center">
                    <th width="5%">No</th>
                    <th>Nama Barang</th>
                    <th width="15%">Harga</th>
                    <th width="10%">Stok</th>
                    <th width="20%">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($barang)) : ?>
                    <?php $no = 1; foreach ($barang as $b) : ?>
                        <tr>
                            <td class="text-center"><?= $no++ ?></td>
                            <td><?= esc($b['nama_barang']) ?></td>
                            <td>Rp <?= number_format($b['harga']) ?></td>
                            <td class="text-center"><?= $b['stok'] ?></td>
                            <td class="text-center">

                                <a href="/barang/edit/<?= $b['id_barang'] ?>" 
                                   class="btn btn-warning btn-sm">
                                    Edit
                                </a>

                                <a href="/barang/hapus/<?= $b['id_barang'] ?>" 
                                   class="btn btn-danger btn-sm"
                                   onclick="return confirm('Yakin ingin menghapus data ini?')">
                                    Hapus
                                </a>

                            </td>
                        </tr>
                    <?php endforeach ?>
                <?php else : ?>
                    <tr>
                        <td colspan="5" class="text-center text-muted">
                            Data barang belum tersedia
                        </td>
                    </tr>
                <?php endif ?>
            </tbody>
        </table>

    </div>
</div>

<?= view('footer') ?>
