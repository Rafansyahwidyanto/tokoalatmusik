<?= view('header') ?>

<h4 class="mb-3">Tambah Penjualan</h4>

<div class="card">
    <div class="card-body">

        <form action="/penjualan/simpan" method="post">

            <div class="mb-2">
                <label class="form-label">Tanggal</label>
                <input type="date" name="tanggal" class="form-control" required>
            </div>

            <div class="mb-2">
                <label class="form-label">Customer</label>
                <select name="id_customer" class="form-control" required>
                    <option value="">-- Pilih Customer --</option>
                    <?php foreach ($customer as $c): ?>
                        <option value="<?= $c['id_customer'] ?>">
                            <?= esc($c['nama_customer']) ?>
                        </option>
                    <?php endforeach ?>
                </select>
            </div>

            <div class="mb-2">
                <label class="form-label">Barang</label>
                <select name="id_barang" id="barang" class="form-control" required>
                    <option value="">-- Pilih Barang --</option>
                    <?php foreach ($barang as $b): ?>
                        <option value="<?= $b['id_barang'] ?>"
                                data-harga="<?= $b['harga'] ?>">
                            <?= esc($b['nama_barang']) ?>
                        </option>
                    <?php endforeach ?>
                </select>
            </div>

            <div class="mb-2">
                <label class="form-label">Qty</label>
                <input type="number" name="qty" id="qty" class="form-control" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Total</label>
                <input type="text"
                       id="total"
                       class="form-control bg-light"
                       readonly>
                </small>
            </div>

            <button class="btn btn-success">Simpan</button>
            <a href="/penjualan" class="btn btn-secondary">Kembali</a>

        </form>

    </div>
</div>

<script>
const barang = document.getElementById('barang');
const qty    = document.getElementById('qty');
const total  = document.getElementById('total');

function hitungTotal() {
    const harga = barang.options[barang.selectedIndex]?.dataset.harga || 0;
    const jumlah = qty.value || 0;
    total.value = 'Rp ' + (harga * jumlah).toLocaleString('id-ID');
}

barang.addEventListener('change', hitungTotal);
qty.addEventListener('input', hitungTotal);
</script>

<?= view('footer') ?>
