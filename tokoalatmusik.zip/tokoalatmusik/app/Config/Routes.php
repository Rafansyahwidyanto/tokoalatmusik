<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
//$routes->get('/', 'Home::index');
$routes->get('/', 'Dashboard::index');

$routes->get('/barang', 'Barang::index');
$routes->get('/barang/tambah', 'Barang::tambah');
$routes->post('/barang/simpan', 'Barang::simpan');
$routes->get('/barang/edit/(:num)', 'Barang::edit/$1');
$routes->post('/barang/update/(:num)', 'Barang::update/$1');
$routes->get('/barang/hapus/(:num)', 'Barang::hapus/$1');

$routes->get('/customer', 'Customer::index');
$routes->get('/customer/tambah', 'Customer::tambah');
$routes->post('/customer/simpan', 'Customer::simpan');
$routes->get('/customer/edit/(:num)', 'Customer::edit/$1');
$routes->post('/customer/update/(:num)', 'Customer::update/$1');
$routes->get('/customer/hapus/(:num)', 'Customer::hapus/$1');

$routes->get('/penjualan', 'Penjualan::index');
$routes->get('/penjualan/tambah', 'Penjualan::tambah');
$routes->post('/penjualan/simpan', 'Penjualan::simpan');
$routes->get('/penjualan/edit/(:num)', 'Penjualan::edit/$1');
$routes->post('/penjualan/update/(:num)', 'Penjualan::update/$1');
$routes->get('/penjualan/hapus/(:num)', 'Penjualan::hapus/$1');

$routes->get('/laporan', 'Laporan::penjualan');
