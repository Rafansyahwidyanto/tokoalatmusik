<?php

namespace App\Controllers;

use App\Models\BarangModel;

class Barang extends BaseController
{
    public function index()
    {
        $model = new BarangModel();
        $data['barang'] = $model->findAll();

        return view('barang_view', $data);
    }

    public function tambah()
    {
        return view('barang_tambah');
    }

    public function simpan()
    {
        $model = new BarangModel();

        $model->save([
            'nama_barang' => $this->request->getPost('nama_barang'),
            'harga'       => $this->request->getPost('harga'),
            'stok'        => $this->request->getPost('stok')
        ]);

        return redirect()->to('/barang');
    }

    public function edit($id)
    {
        $model = new BarangModel();
        $data['barang'] = $model->find($id);

        return view('barang_edit', $data);
    }

    public function update($id)
    {
        $model = new BarangModel();

        $model->update($id, [
            'nama_barang' => $this->request->getPost('nama_barang'),
            'harga'       => $this->request->getPost('harga'),
            'stok'        => $this->request->getPost('stok')
        ]);

        return redirect()->to('/barang');
    }

    public function hapus($id)
    {
        $model = new BarangModel();
        $model->delete($id);

        return redirect()->to('/barang');
    }
}
