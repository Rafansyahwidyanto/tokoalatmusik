<?php
namespace App\Controllers;

class Laporan extends BaseController
{
    public function penjualan()
    {
        $db = \Config\Database::connect();
        $data['laporan'] = $db->query("
            SELECT penjualan.tanggal, customer.nama_customer, penjualan.total
            FROM penjualan
            JOIN customer ON penjualan.id_customer = customer.id_customer
        ")->getResult();

        return view('laporan_penjualan_view', $data);
    }
}
