<?php

namespace App\Controllers;

use App\Models\PenjualanModel;
use App\Models\BarangModel;
use App\Models\CustomerModel;

class Penjualan extends BaseController
{
    public function index()
    {
        $data['penjualan'] = (new PenjualanModel())->getPenjualan();
        return view('penjualan_view', $data);
    }

    public function tambah()
    {
        $data['barang']   = (new BarangModel())->findAll();
        $data['customer'] = (new CustomerModel())->findAll();
        return view('penjualan_tambah', $data);
    }

    public function simpan()
    {
        $barang = (new BarangModel())->find(
            $this->request->getPost('id_barang')
        );

        $qty   = (int)$this->request->getPost('qty');
        $total = $barang['harga'] * $qty;

        (new PenjualanModel())->save([
            'id_barang'   => $this->request->getPost('id_barang'),
            'id_customer' => $this->request->getPost('id_customer'),
            'tanggal'     => $this->request->getPost('tanggal'),
            'qty'         => $qty,
            'total'       => $total
        ]);

        return redirect()->to('/penjualan');
    }

    public function edit($id)
    {
        $data['penjualan'] = (new PenjualanModel())->find($id);
        $data['barang']    = (new BarangModel())->findAll();
        $data['customer']  = (new CustomerModel())->findAll();

        return view('penjualan_edit', $data);
    }

    public function update($id)
    {
        $model       = new PenjualanModel();
        $barangModel = new BarangModel();

        $barang = $barangModel->find(
            $this->request->getPost('id_barang')
        );

        $qty   = (int)$this->request->getPost('qty');
        $total = $barang['harga'] * $qty;

        $model->update($id, [
            'id_barang'   => $this->request->getPost('id_barang'),
            'id_customer' => $this->request->getPost('id_customer'),
            'tanggal'     => $this->request->getPost('tanggal'),
            'qty'         => $qty,
            'total'       => $total
        ]);

        return redirect()->to('/penjualan');
    }

    public function hapus($id)
    {
        (new PenjualanModel())->delete($id);
        return redirect()->to('/penjualan');
    }
}
