<?php
namespace App\Controllers;

use App\Models\BarangModel;
use App\Models\CustomerModel;
use App\Models\PenjualanModel;

class Dashboard extends BaseController
{
    public function index()
    {
        $barangModel    = new BarangModel();
        $customerModel  = new CustomerModel();
        $penjualanModel = new PenjualanModel();

        $data = [
            'total_barang'    => $barangModel->countAllResults(),
            'total_customer'  => $customerModel->countAllResults(),
            'total_penjualan' => $penjualanModel->countAllResults(),
            'total_pendapatan'=> $penjualanModel
                                    ->selectSum('total')
                                    ->get()
                                    ->getRow()
                                    ->total ?? 0
        ];

        return view('dashboard_view', $data);
    }
}
