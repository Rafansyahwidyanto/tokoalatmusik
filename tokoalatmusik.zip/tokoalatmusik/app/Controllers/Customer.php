<?php

namespace App\Controllers;

use App\Models\CustomerModel;

class Customer extends BaseController
{
    public function index()
    {
        $model = new CustomerModel();
        $data['customer'] = $model->findAll();

        return view('customer_view', $data);
    }

    public function tambah()
    {
        return view('customer_tambah');
    }

    public function simpan()
    {
        $model = new CustomerModel();

        $model->save([
            'nama_customer' => $this->request->getPost('nama_customer'),
            'alamat'        => $this->request->getPost('alamat'),
            'no_hp'         => $this->request->getPost('no_hp')
        ]);

        return redirect()->to('/customer');
    }

    public function edit($id)
    {
        $model = new CustomerModel();
        $data['customer'] = $model->find($id);

        if (!$data['customer']) {
            return redirect()->to('/customer');
        }

        return view('customer_edit', $data);
    }

    public function update($id)
    {
        $model = new CustomerModel();

        $model->update($id, [
            'nama_customer' => $this->request->getPost('nama_customer'),
            'alamat'        => $this->request->getPost('alamat'),
            'no_hp'         => $this->request->getPost('no_hp')
        ]);

        return redirect()->to('/customer');
    }

    public function hapus($id)
    {
        $model = new CustomerModel();
        $model->delete($id);

        return redirect()->to('/customer');
    }
}
